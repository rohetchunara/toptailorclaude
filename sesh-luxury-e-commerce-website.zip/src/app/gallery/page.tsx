import type { Metadata } from "next";
import GalleryGrid from "@/components/GalleryGrid";

export const metadata: Metadata = {
  title: "Gallery | Top Tailor",
  description: "A lookbook of Top Tailor clients, weddings, and events — bespoke suits and Daura Suruwal in the wild.",
};

export default function GalleryPage() {
  return (
    <main className="min-h-screen bg-[var(--bg)]">
      <section className="border-b border-[var(--hairline)] py-20 md:py-28">
        <div className="mx-auto max-w-3xl px-6 text-center md:px-10">
          <p className="text-[0.65rem] uppercase tracking-[0.5em] text-[var(--ink-soft)]">Gallery</p>
          <h1 className="mt-5 font-display text-5xl text-[var(--ink)] sm:text-6xl">
            Moments in Tailoring
          </h1>
          <p className="mt-6 text-sm leading-relaxed text-[var(--ink-soft)] sm:text-base">
            A running lookbook of our clients, weddings, and evenings — captured in the suits
            and Daura Suruwal we made for them.
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-[1600px] px-6 py-16 md:px-10">
        <GalleryGrid />
      </section>
    </main>
  );
}
