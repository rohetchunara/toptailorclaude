import type { Metadata } from "next";
import StoreInquiryForm from "@/components/StoreInquiryForm";

export const metadata: Metadata = {
  title: "Store Locations | Top Tailor",
  description: "Visit a Top Tailor boutique in Kathmandu, Lalitpur, or Pokhara for consultations and fittings.",
};

const stores = [
  {
    city: "Kathmandu — Flagship",
    address: "Durbar Marg, Kathmandu 44600, Nepal",
    phone: "+977 1-4123456",
    hours: "Mon – Sat: 10:00 AM – 7:00 PM",
    note: "Full bespoke atelier with three fitting rooms and an in-house cutter.",
  },
  {
    city: "Lalitpur — Design Studio",
    address: "Jhamsikhel, Lalitpur 44700, Nepal",
    phone: "+977 1-5123456",
    hours: "Tue – Sun: 11:00 AM – 6:30 PM",
    note: "Focused on Daura Suruwal and ceremonial wear consultations.",
  },
  {
    city: "Pokhara — Boutique",
    address: "Lakeside Road, Pokhara 33700, Nepal",
    phone: "+977 61-512345",
    hours: "Mon – Sat: 10:30 AM – 6:00 PM",
    note: "Made-to-measure suiting and ready-to-wear collection.",
  },
];

export default function StoresPage() {
  return (
    <main className="bg-[var(--bg)]">
      <section className="border-b border-[var(--hairline)] py-20 md:py-28">
        <div className="mx-auto max-w-3xl px-6 text-center md:px-10">
          <p className="text-[0.65rem] uppercase tracking-[0.5em] text-[var(--ink-soft)]">
            Store Locations
          </p>
          <h1 className="mt-5 font-display text-5xl text-[var(--ink)] sm:text-6xl">
            Visit an Atelier
          </h1>
          <p className="mt-6 text-sm leading-relaxed text-[var(--ink-soft)] sm:text-base">
            Three boutiques across Nepal, each staffed by master tailors ready for consultation,
            measurement, and fitting.
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-[1400px] px-6 py-20 md:px-10">
        <div className="grid gap-16 lg:grid-cols-[1.2fr_1fr]">
          <div className="grid gap-8 sm:grid-cols-2">
            {stores.map((store) => (
              <div
                key={store.city}
                className="flex flex-col rounded-2xl border border-[var(--hairline)] p-7 transition-transform duration-500 hover:-translate-y-1.5"
              >
                <h2 className="font-display text-2xl text-[var(--ink)]">{store.city}</h2>
                <p className="mt-4 text-sm text-[var(--ink-soft)]">{store.address}</p>
                <p className="mt-2 text-sm text-[var(--ink-soft)]">{store.phone}</p>
                <p className="mt-2 text-sm text-[var(--ink-soft)]">{store.hours}</p>
                <p className="mt-4 flex-1 text-sm leading-relaxed text-[var(--ink-soft)]">{store.note}</p>
              </div>
            ))}

            <div className="flex flex-col justify-center rounded-2xl bg-[var(--ink)] p-7 text-[var(--bg)] sm:col-span-2">
              <p className="font-display text-2xl">Prefer to shop from home?</p>
              <p className="mt-3 text-sm opacity-80">
                Browse the full catalog online or start a custom order — we ship nationwide with
                complimentary alterations at your nearest boutique.
              </p>
            </div>
          </div>

          <div className="rounded-2xl border border-[var(--hairline)] p-8 md:p-10">
            <h2 className="font-display text-2xl text-[var(--ink)]">Get in Touch</h2>
            <p className="mt-3 text-sm text-[var(--ink-soft)]">
              Have a question about a specific boutique? Send us a note.
            </p>
            <div className="mt-8">
              <StoreInquiryForm stores={stores} />
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}
