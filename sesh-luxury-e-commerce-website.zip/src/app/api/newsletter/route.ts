import { db } from "@/db";
import { newsletterSubscribers } from "@/db/schema";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const email = typeof body?.email === "string" ? body.email.trim().toLowerCase() : "";

    if (!email || !email.includes("@")) {
      return Response.json({ ok: false, error: "A valid email is required." }, { status: 400 });
    }

    await db
      .insert(newsletterSubscribers)
      .values({ email })
      .onConflictDoNothing({ target: newsletterSubscribers.email });

    return Response.json({ ok: true });
  } catch (error) {
    console.error("newsletter signup failed", error);
    return Response.json({ ok: false, error: "Something went wrong." }, { status: 500 });
  }
}
