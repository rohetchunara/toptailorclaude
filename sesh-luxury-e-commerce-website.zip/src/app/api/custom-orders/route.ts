import { db } from "@/db";
import { customOrders } from "@/db/schema";
import { desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const rows = await db.select().from(customOrders).orderBy(desc(customOrders.createdAt)).limit(200);
    return Response.json({ ok: true, orders: rows });
  } catch (error) {
    console.error("failed to load custom orders", error);
    return Response.json({ ok: false, error: "Unable to load orders." }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const fullName = typeof body?.fullName === "string" ? body.fullName.trim() : "";
    const email = typeof body?.email === "string" ? body.email.trim() : "";
    const garmentType = typeof body?.garmentType === "string" ? body.garmentType.trim() : "";

    if (!fullName || !email || !garmentType) {
      return Response.json(
        { ok: false, error: "Full name, email, and garment type are required." },
        { status: 400 }
      );
    }

    const [order] = await db
      .insert(customOrders)
      .values({
        fullName,
        email,
        phone: typeof body?.phone === "string" ? body.phone.trim() : null,
        garmentType,
        fabricPreference:
          typeof body?.fabricPreference === "string" ? body.fabricPreference.trim() : null,
        measurements: typeof body?.measurements === "object" ? body.measurements : null,
        notes: typeof body?.notes === "string" ? body.notes.trim() : null,
      })
      .returning();

    return Response.json({ ok: true, order });
  } catch (error) {
    console.error("failed to submit custom order", error);
    return Response.json({ ok: false, error: "Something went wrong." }, { status: 500 });
  }
}
