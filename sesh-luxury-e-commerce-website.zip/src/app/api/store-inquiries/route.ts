import { db } from "@/db";
import { storeInquiries } from "@/db/schema";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const name = typeof body?.name === "string" ? body.name.trim() : "";
    const email = typeof body?.email === "string" ? body.email.trim() : "";
    const message = typeof body?.message === "string" ? body.message.trim() : "";

    if (!name || !email || !message) {
      return Response.json({ ok: false, error: "Name, email and message are required." }, { status: 400 });
    }

    await db.insert(storeInquiries).values({
      name,
      email,
      message,
      storeCity: typeof body?.storeCity === "string" ? body.storeCity.trim() : null,
    });

    return Response.json({ ok: true });
  } catch (error) {
    console.error("failed to submit store inquiry", error);
    return Response.json({ ok: false, error: "Something went wrong." }, { status: 500 });
  }
}
