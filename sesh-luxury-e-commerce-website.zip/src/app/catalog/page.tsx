import { Suspense } from "react";
import type { Metadata } from "next";
import CatalogGrid from "@/components/CatalogGrid";

export const metadata: Metadata = {
  title: "Catalog | Top Tailor",
  description: "Browse the full Top Tailor collection of suits, tuxedos, blazers, and Daura Suruwal priced in NPR.",
};

export default function CatalogPage() {
  return (
    <main className="min-h-screen bg-[var(--bg)] pt-6">
      <Suspense fallback={<div className="px-6 py-24 text-center text-[var(--ink-soft)]">Loading catalog…</div>}>
        <CatalogGrid />
      </Suspense>
    </main>
  );
}
