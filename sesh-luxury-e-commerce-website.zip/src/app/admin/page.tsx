import type { Metadata } from "next";
import { db } from "@/db";
import { customOrders, newsletterSubscribers, storeInquiries } from "@/db/schema";
import { desc } from "drizzle-orm";

export const metadata: Metadata = {
  title: "Admin | Top Tailor",
  robots: { index: false, follow: false },
};

export const dynamic = "force-dynamic";

export default async function AdminPage() {
  const [orders, subscribers, inquiries] = await Promise.all([
    db.select().from(customOrders).orderBy(desc(customOrders.createdAt)).limit(100),
    db.select().from(newsletterSubscribers).orderBy(desc(newsletterSubscribers.createdAt)).limit(100),
    db.select().from(storeInquiries).orderBy(desc(storeInquiries.createdAt)).limit(100),
  ]);

  return (
    <main className="min-h-screen bg-[var(--bg)] px-6 py-16 md:px-10">
      <div className="mx-auto max-w-[1400px]">
        <p className="text-[0.65rem] uppercase tracking-[0.5em] text-[var(--ink-soft)]">
          Restricted &mdash; Internal Use Only
        </p>
        <h1 className="mt-4 font-display text-4xl text-[var(--ink)] sm:text-5xl">
          Top Tailor Admin
        </h1>
        <p className="mt-3 text-sm text-[var(--ink-soft)]">
          Reached via the hidden Shift+T+O+P shortcut (desktop) or 5 taps on the footer credit
          line (mobile).
        </p>

        <section className="mt-14">
          <h2 className="font-display text-2xl text-[var(--ink)]">
            Custom Order Requests ({orders.length})
          </h2>
          <div className="mt-6 overflow-x-auto rounded-xl border border-[var(--hairline)]">
            <table className="w-full min-w-[720px] text-left text-sm">
              <thead>
                <tr className="border-b border-[var(--hairline)] text-[var(--ink-soft)]">
                  <th className="px-4 py-3 font-normal">Name</th>
                  <th className="px-4 py-3 font-normal">Email</th>
                  <th className="px-4 py-3 font-normal">Garment</th>
                  <th className="px-4 py-3 font-normal">Fabric</th>
                  <th className="px-4 py-3 font-normal">Status</th>
                  <th className="px-4 py-3 font-normal">Submitted</th>
                </tr>
              </thead>
              <tbody>
                {orders.length === 0 && (
                  <tr>
                    <td colSpan={6} className="px-4 py-6 text-center text-[var(--ink-soft)]">
                      No custom order requests yet.
                    </td>
                  </tr>
                )}
                {orders.map((order) => (
                  <tr key={order.id} className="border-b border-[var(--hairline)] text-[var(--ink)]">
                    <td className="px-4 py-3">{order.fullName}</td>
                    <td className="px-4 py-3">{order.email}</td>
                    <td className="px-4 py-3">{order.garmentType}</td>
                    <td className="px-4 py-3">{order.fabricPreference || "—"}</td>
                    <td className="px-4 py-3 capitalize">{order.status}</td>
                    <td className="px-4 py-3">{new Date(order.createdAt).toLocaleString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        <section className="mt-16">
          <h2 className="font-display text-2xl text-[var(--ink)]">
            Store Inquiries ({inquiries.length})
          </h2>
          <div className="mt-6 overflow-x-auto rounded-xl border border-[var(--hairline)]">
            <table className="w-full min-w-[720px] text-left text-sm">
              <thead>
                <tr className="border-b border-[var(--hairline)] text-[var(--ink-soft)]">
                  <th className="px-4 py-3 font-normal">Name</th>
                  <th className="px-4 py-3 font-normal">Email</th>
                  <th className="px-4 py-3 font-normal">Boutique</th>
                  <th className="px-4 py-3 font-normal">Message</th>
                  <th className="px-4 py-3 font-normal">Submitted</th>
                </tr>
              </thead>
              <tbody>
                {inquiries.length === 0 && (
                  <tr>
                    <td colSpan={5} className="px-4 py-6 text-center text-[var(--ink-soft)]">
                      No store inquiries yet.
                    </td>
                  </tr>
                )}
                {inquiries.map((inquiry) => (
                  <tr key={inquiry.id} className="border-b border-[var(--hairline)] text-[var(--ink)]">
                    <td className="px-4 py-3">{inquiry.name}</td>
                    <td className="px-4 py-3">{inquiry.email}</td>
                    <td className="px-4 py-3">{inquiry.storeCity || "—"}</td>
                    <td className="px-4 py-3 max-w-xs truncate">{inquiry.message}</td>
                    <td className="px-4 py-3">{new Date(inquiry.createdAt).toLocaleString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        <section className="mt-16 mb-10">
          <h2 className="font-display text-2xl text-[var(--ink)]">
            Newsletter Subscribers ({subscribers.length})
          </h2>
          <div className="mt-6 flex flex-wrap gap-3">
            {subscribers.length === 0 && (
              <p className="text-sm text-[var(--ink-soft)]">No subscribers yet.</p>
            )}
            {subscribers.map((sub) => (
              <span
                key={sub.id}
                className="rounded-full border border-[var(--hairline)] px-4 py-2 text-xs text-[var(--ink)]"
              >
                {sub.email}
              </span>
            ))}
          </div>
        </section>
      </div>
    </main>
  );
}
