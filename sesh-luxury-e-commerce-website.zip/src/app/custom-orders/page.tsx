import type { Metadata } from "next";
import CustomOrderForm from "@/components/CustomOrderForm";

export const metadata: Metadata = {
  title: "Custom Orders | Top Tailor",
  description: "Learn how to place a bespoke order with Top Tailor and measure yourself accurately at home.",
};

const measureSteps = [
  {
    title: "Chest",
    text: "Wrap the tape under your arms, across the fullest part of your chest. Keep the tape parallel to the floor, breathe normally.",
  },
  {
    title: "Waist",
    text: "Measure around your natural waistline — typically just above the belly button — without pulling the tape tight.",
  },
  {
    title: "Shoulder Width",
    text: "Measure from the edge of one shoulder to the other, across your back, following the natural shoulder seam line.",
  },
  {
    title: "Sleeve Length",
    text: "With your arm slightly bent, measure from the shoulder edge to the wrist bone.",
  },
  {
    title: "Inseam",
    text: "Measure from the crotch seam to the bottom of the ankle along the inside of your leg.",
  },
  {
    title: "Neck",
    text: "Wrap the tape around the base of your neck, where a shirt collar would sit, leaving one finger of ease.",
  },
];

const orderSteps = [
  "Submit the request form below with your details, garment type, and fabric direction.",
  "Our consultant contacts you within 24 hours to confirm scope, price, and timeline.",
  "Provide measurements using the at-home guide, or book an in-atelier fitting.",
  "Approve your fabric swatch and design details before cutting begins.",
  "Receive fitting updates and a final delivery date — with complimentary alterations.",
];

export default function CustomOrdersPage() {
  return (
    <main className="bg-[var(--bg)]">
      <section className="border-b border-[var(--hairline)] py-20 md:py-28">
        <div className="mx-auto max-w-3xl px-6 text-center md:px-10">
          <p className="text-[0.65rem] uppercase tracking-[0.5em] text-[var(--ink-soft)]">
            Custom Orders
          </p>
          <h1 className="mt-5 font-display text-5xl text-[var(--ink)] sm:text-6xl">
            Order Bespoke, From Anywhere
          </h1>
          <p className="mt-6 text-sm leading-relaxed text-[var(--ink-soft)] sm:text-base">
            No boutique nearby? No problem. Follow our simple guide to place a custom order and
            take your own measurements accurately, from the comfort of home.
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-[1300px] px-6 py-20 md:px-10">
        <h2 className="font-display text-3xl text-[var(--ink)] sm:text-4xl">How Ordering Works</h2>
        <ol className="mt-10 grid gap-8 sm:grid-cols-2 lg:grid-cols-5">
          {orderSteps.map((step, i) => (
            <li key={step} className="border-t border-[var(--hairline)] pt-5">
              <span className="font-display text-2xl text-[var(--accent)]">{`0${i + 1}`}</span>
              <p className="mt-3 text-sm leading-relaxed text-[var(--ink-soft)]">{step}</p>
            </li>
          ))}
        </ol>
      </section>

      <section className="border-t border-[var(--hairline)] bg-[var(--bg)] py-20 md:py-28">
        <div className="mx-auto max-w-[1300px] px-6 md:px-10">
          <div className="grid gap-16 lg:grid-cols-[1fr_1fr]">
            <div>
              <h2 className="font-display text-3xl text-[var(--ink)] sm:text-4xl">
                Measure Yourself at Home
              </h2>
              <p className="mt-4 text-sm leading-relaxed text-[var(--ink-soft)]">
                You will need a soft measuring tape, a mirror, and — ideally — a friend to help.
                Wear light, fitted clothing for the most accurate results.
              </p>
              <div className="mt-8 flex flex-col gap-6">
                {measureSteps.map((step) => (
                  <div key={step.title} className="border-b border-[var(--hairline)] pb-6">
                    <h3 className="font-display text-xl text-[var(--ink)]">{step.title}</h3>
                    <p className="mt-2 text-sm leading-relaxed text-[var(--ink-soft)]">{step.text}</p>
                  </div>
                ))}
              </div>
            </div>

            <div className="rounded-2xl border border-[var(--hairline)] p-8 md:p-10">
              <h2 className="font-display text-2xl text-[var(--ink)] sm:text-3xl">
                Submit Your Custom Order
              </h2>
              <p className="mt-3 text-sm text-[var(--ink-soft)]">
                Fill in as much detail as you can — you may leave measurements for a later
                consultation call.
              </p>
              <div className="mt-8">
                <CustomOrderForm />
              </div>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}
