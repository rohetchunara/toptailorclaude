import { db } from "@/db";
import { sql } from "drizzle-orm";
import Hero from "@/components/Hero";
import ThreeSuitViewer1 from "@/components/ThreeSuitViewer1";
import ThreeSuitViewer2 from "@/components/ThreeSuitViewer2";
import ThreeSuitViewer3 from "@/components/ThreeSuitViewer3";
import HomeCatalogPreview from "@/components/HomeCatalogPreview";
import BespokeTeaser from "@/components/BespokeTeaser";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  await db.execute(sql`select 1`);

  return (
    <main className="bg-[var(--bg)]">
      <Hero />
      <ThreeSuitViewer1 />
      <ThreeSuitViewer2 />
      <ThreeSuitViewer3 />
      <HomeCatalogPreview />
      <BespokeTeaser />
    </main>
  );
}
