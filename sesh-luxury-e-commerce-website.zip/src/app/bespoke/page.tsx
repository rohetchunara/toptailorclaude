import type { Metadata } from "next";
import Link from "next/link";
import { formatNPR } from "@/data/products";

export const metadata: Metadata = {
  title: "Bespoke Services | Top Tailor",
  description: "Explore Top Tailor's bespoke tailoring journey — consultation, fabric selection, fittings, and hand-finishing.",
};

const steps = [
  {
    number: "01",
    title: "Private Consultation",
    text: "Begin with an in-atelier or virtual consultation. Discuss silhouette, occasion, and fabric direction with a Top Tailor cutter.",
  },
  {
    number: "02",
    title: "Fabric & Detailing",
    text: "Select from our curated mills — merino wool, Dhaka silk blends, linen, and barathea — alongside lining, buttons, and monogramming.",
  },
  {
    number: "03",
    title: "Precision Measurement",
    text: "Over 20 measurement points captured by hand, or guided remotely using our at-home measurement kit and video fitting.",
  },
  {
    number: "04",
    title: "First Fitting",
    text: "A baste fitting on your half-finished garment ensures posture, drape, and proportion are exact before final construction.",
  },
  {
    number: "05",
    title: "Hand-Finishing",
    text: "Our artisans hand-stitch buttonholes, canvas, and edges — the final polish that defines true bespoke craft.",
  },
  {
    number: "06",
    title: "Delivery & Aftercare",
    text: "Receive your garment with a complimentary press, and lifetime alteration support at any Top Tailor boutique.",
  },
];

const tiers = [
  {
    name: "Made-to-Measure",
    price: 45000,
    desc: "Pattern-adjusted from our house block to your measurements. 2–3 week turnaround.",
  },
  {
    name: "Full Bespoke Suit",
    price: 95000,
    desc: "A unique paper pattern cut from scratch, three fittings, entirely hand-finished. 5–6 week turnaround.",
  },
  {
    name: "Heritage Daura Suruwal",
    price: 55000,
    desc: "Hand-loomed Dhaka fabric, gold embroidery, and traditional tailoring for ceremonial occasions.",
  },
];

export default function BespokePage() {
  return (
    <main className="bg-[var(--bg)]">
      <section className="relative flex min-h-[60vh] items-center justify-center overflow-hidden border-b border-[var(--hairline)]">
        <img
          src="/images/gallery-event.jpg"
          alt="Bespoke tailoring consultation"
          className="absolute inset-0 h-full w-full object-cover opacity-40 dark:opacity-30"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-[var(--bg)]/30 via-[var(--bg)]/60 to-[var(--bg)]" />
        <div className="relative z-10 flex flex-col items-center px-6 text-center">
          <p className="text-[0.65rem] uppercase tracking-[0.5em] text-[var(--ink-soft)]">
            Bespoke Services
          </p>
          <h1 className="mt-5 font-display text-5xl text-[var(--ink)] sm:text-6xl md:text-7xl">
            Tailored, Truly Yours
          </h1>
          <p className="mt-6 max-w-xl text-sm leading-relaxed text-[var(--ink-soft)] sm:text-base">
            Every Top Tailor bespoke garment is built around one person: you. From the first
            sketch to the final stitch, nothing is off the rack.
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-[1400px] px-6 py-24 md:px-10">
        <h2 className="text-center font-display text-3xl text-[var(--ink)] sm:text-4xl">
          The Bespoke Journey
        </h2>
        <div className="mt-16 grid gap-x-10 gap-y-16 sm:grid-cols-2 lg:grid-cols-3">
          {steps.map((step) => (
            <div key={step.number} className="border-t border-[var(--hairline)] pt-6">
              <span className="font-display text-3xl text-[var(--accent)]">{step.number}</span>
              <h3 className="mt-4 font-display text-xl text-[var(--ink)]">{step.title}</h3>
              <p className="mt-3 text-sm leading-relaxed text-[var(--ink-soft)]">{step.text}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="border-t border-[var(--hairline)] bg-[var(--bg)] py-24">
        <div className="mx-auto max-w-[1400px] px-6 md:px-10">
          <h2 className="text-center font-display text-3xl text-[var(--ink)] sm:text-4xl">
            Service Tiers
          </h2>
          <div className="mt-14 grid gap-8 md:grid-cols-3">
            {tiers.map((tier) => (
              <div
                key={tier.name}
                className="flex flex-col rounded-2xl border border-[var(--hairline)] p-8 transition-transform duration-500 hover:-translate-y-2"
              >
                <h3 className="font-display text-2xl text-[var(--ink)]">{tier.name}</h3>
                <p className="mt-4 font-display text-3xl text-[var(--accent)]">
                  From {formatNPR(tier.price)}
                </p>
                <p className="mt-4 flex-1 text-sm leading-relaxed text-[var(--ink-soft)]">{tier.desc}</p>
                <Link
                  href="/custom-orders"
                  className="mt-8 border border-[var(--ink)] py-3.5 text-center text-[0.7rem] uppercase tracking-[0.25em] text-[var(--ink)] transition-colors hover:bg-[var(--ink)] hover:text-[var(--bg)]"
                >
                  Begin This Journey
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>
    </main>
  );
}
