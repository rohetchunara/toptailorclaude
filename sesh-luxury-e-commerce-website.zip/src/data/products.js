// Structured product catalog for Top Tailor.
// All prices are in Nepali Rupees (NPR).

export const formatNPR = (amount) =>
  `NPR ${amount.toLocaleString("en-IN")}`;

export const categories = [
  { id: "all", label: "All" },
  { id: "suits", label: "Suits" },
  { id: "tuxedos", label: "Tuxedos" },
  { id: "daura-suruwal", label: "Daura Suruwal" },
  { id: "blazers", label: "Blazers" },
  { id: "waistcoats", label: "Waistcoats" },
];

// Dedicated hero showcase pieces used by the 3D scroll experience.
export const showcaseProducts = [
  {
    id: "showcase-navy-pinstripe",
    name: "The Regent Pinstripe",
    category: "suits",
    price: 68500,
    image: "/images/viewer-suit-navy.jpg",
    fabric: "Super 120s Merino Wool, Navy Pinstripe",
    lining: "Bemberg Cupro, Half Canvas Construction",
    origin: "Hand-cut & stitched in-house, Kathmandu Atelier",
    details: [
      "Three-piece silhouette with a structured, roped shoulder",
      "Peak lapel jacket, pick-stitched edges, horn buttons",
      "Fully adjustable waistcoat back strap",
      "Tapered trouser with a clean break",
    ],
    description:
      "A power silhouette built on Super 120s merino wool. The Regent Pinstripe is cut for boardrooms and grand entrances alike — sharp lines, a roped shoulder, and pick-stitched detailing throughout.",
  },
  {
    id: "showcase-black-tuxedo",
    name: "The Midnight Tuxedo",
    category: "tuxedos",
    price: 82000,
    image: "/images/viewer-tuxedo-black.jpg",
    fabric: "Italian Barathea Wool with Satin Peak Lapel",
    lining: "Full Bemberg Silk Lining",
    origin: "Hand-finished, Top Tailor Atelier",
    details: [
      "Satin peak lapel with hand-stitched buttonhole",
      "Single-button closure, jetted pockets",
      "Satin-trimmed trouser with silk waistband",
      "Formal grosgrain bow tie included",
    ],
    description:
      "Reserved for the nights that matter. The Midnight Tuxedo is cut from Italian barathea wool with a full silk lining, satin peak lapel, and a razor-clean drape from shoulder to hem.",
  },
  {
    id: "showcase-daura-suruwal",
    name: "The Heritage Daura Suruwal",
    category: "daura-suruwal",
    price: 45000,
    image: "/images/viewer-daura-suruwal.jpg",
    fabric: "Hand-loomed Dhaka Silk Blend, Maroon & Gold",
    lining: "Pure Cotton Inner Lining",
    origin: "Hand-embroidered, Kathmandu Valley Artisans",
    details: [
      "Traditional eight-string closure, hand-tied",
      "Gold-trimmed Dhaka topi included",
      "Hand-embroidered collar and cuff detailing",
      "Tailored Suruwal with a modern slim taper",
    ],
    description:
      "A tribute to Nepali heritage, reimagined for the modern gentleman. Hand-loomed Dhaka silk, gold embroidery, and a tailored taper make this the definitive ceremonial ensemble.",
  },
];

export const products = [
  ...showcaseProducts,
  {
    id: "prod-charcoal-suit",
    name: "The Ashford Charcoal",
    category: "suits",
    price: 58500,
    image: "/images/catalog-suit-charcoal.jpg",
    fabric: "Super 110s Wool, Charcoal Grey",
    lining: "Half Canvas, Cupro Lining",
    origin: "Kathmandu Atelier",
    details: [
      "Notch lapel, two-button closure",
      "Slim modern fit with a soft shoulder",
      "Functional surgeon's cuffs",
      "Flat-front tapered trouser",
    ],
    description:
      "A versatile charcoal suit built for daily excellence — equally at home in the boardroom or an evening reception.",
  },
  {
    id: "prod-tweed-suit",
    name: "The Windermere Tweed",
    category: "suits",
    price: 72000,
    image: "/images/catalog-suit-tweed.jpg",
    fabric: "Brown Herringbone Tweed, Wool Blend",
    lining: "Quarter Canvas, Silk-blend Lining",
    origin: "Kathmandu Atelier",
    details: [
      "Three-piece with elbow-patch option",
      "Peak lapel waistcoat",
      "Structured shoulder, heavier hand-feel cloth",
      "Ideal for autumn and winter occasions",
    ],
    description:
      "Rich herringbone texture and a countryside soul, tailored with the same precision as our formal suiting line.",
  },
  {
    id: "prod-royal-daura",
    name: "The Royal Dhaka",
    category: "daura-suruwal",
    price: 41500,
    image: "/images/catalog-daura-royal.jpg",
    fabric: "Hand-loomed Dhaka Cotton Silk, Royal Blue",
    lining: "Pure Cotton Inner Lining",
    origin: "Kathmandu Valley Artisans",
    details: [
      "Classic collar with gold piping",
      "Matching Dhaka topi included",
      "Hand-finished button placket",
      "Tailored Suruwal, ankle taper",
    ],
    description:
      "Royal blue Dhaka silk with gold piping — a striking, celebration-ready ensemble rooted in tradition.",
  },
  {
    id: "prod-linen-blazer",
    name: "The Positano Linen Blazer",
    category: "blazers",
    price: 34500,
    image: "/images/catalog-blazer-linen.jpg",
    fabric: "100% Belgian Linen, Beige",
    lining: "Unlined, Breathable Construction",
    origin: "Kathmandu Atelier",
    details: [
      "Unstructured shoulder for a relaxed drape",
      "Patch pockets, horn buttons",
      "Breathable, ideal for warm-weather events",
      "Pairs seamlessly with tailored trousers or chinos",
    ],
    description:
      "Effortless warm-weather tailoring in pure Belgian linen — soft shoulders, breathable construction, unmistakable ease.",
  },
  {
    id: "prod-navy-waistcoat",
    name: "The Sterling Waistcoat",
    category: "waistcoats",
    price: 18500,
    image: "/images/viewer-suit-navy.jpg",
    fabric: "Super 120s Merino Wool, Navy",
    lining: "Satin Back Strap",
    origin: "Kathmandu Atelier",
    details: [
      "Five-button front, adjustable back strap",
      "Two welt pockets",
      "Designed to pair with our full suiting range",
      "Also available as a standalone formal piece",
    ],
    description:
      "A sharp, standalone waistcoat that layers beautifully beneath any of our tailored jackets.",
  },
  {
    id: "prod-black-daura",
    name: "The Onyx Daura Suruwal",
    category: "daura-suruwal",
    price: 47500,
    image: "/images/viewer-daura-suruwal.jpg",
    fabric: "Hand-loomed Dhaka Silk Blend, Black & Gold",
    lining: "Pure Cotton Inner Lining",
    origin: "Kathmandu Valley Artisans",
    details: [
      "Understated black base with gold trim",
      "Modern slim Suruwal taper",
      "Hand-tied eight-string closure",
      "Dhaka topi included",
    ],
    description:
      "For the gentleman who prefers restraint — a black and gold Daura Suruwal balancing heritage with modern minimalism.",
  },
  {
    id: "prod-formal-tuxedo-ivory",
    name: "The Riviera Ivory Dinner Jacket",
    category: "tuxedos",
    price: 76500,
    image: "/images/catalog-blazer-linen.jpg",
    fabric: "Ivory Mohair-Wool Blend",
    lining: "Full Bemberg Silk Lining",
    origin: "Top Tailor Atelier",
    details: [
      "Shawl collar in self-fabric",
      "Single-button closure",
      "Ideal for summer galas and destination events",
      "Paired best with classic black formal trousers",
    ],
    description:
      "A warm-weather formal statement — ivory mohair-wool with a silk shawl collar, cut for unforgettable evenings.",
  },
  {
    id: "prod-grey-check-suit",
    name: "The Chelsea Check",
    category: "suits",
    price: 61500,
    image: "/images/catalog-suit-charcoal.jpg",
    fabric: "Grey Prince of Wales Check Wool",
    lining: "Half Canvas, Cupro Lining",
    origin: "Kathmandu Atelier",
    details: [
      "Timeless Prince of Wales check",
      "Two-button notch lapel jacket",
      "Slim modern fit",
      "Flat-front trouser, side adjusters",
    ],
    description:
      "A refined check suiting option for gentlemen who favor pattern with restraint and precision tailoring.",
  },
];

export const getProductById = (id) => products.find((product) => product.id === id);
